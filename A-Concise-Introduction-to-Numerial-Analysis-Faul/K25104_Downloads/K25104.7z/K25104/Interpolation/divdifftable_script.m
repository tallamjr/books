% Usage example for divdifftable
% related to Exercise 3.13

nodes = [4;
    6;
    8;
    10];
values = [1;
    3;
    8;
    20];

[d] = divdifftable( nodes, values )