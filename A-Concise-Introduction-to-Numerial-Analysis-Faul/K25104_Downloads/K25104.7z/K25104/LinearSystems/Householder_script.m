% Usage example for Householder
% related to Exercise 2.9 

v = [3;
    -6;
    2];

[ x ] = Householder( v,1 )