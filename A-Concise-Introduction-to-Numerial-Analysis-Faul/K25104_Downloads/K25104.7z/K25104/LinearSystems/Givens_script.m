% Usage example for Givens
% related to Exercise 2.8 

A = [3 6 -1;
    -6 -6 1;
    2 1 -1];

[ B,G ] = Givens( A,2,1 )