% Usage example for Gram_Schmidt
% related to Exercise 2.7 

A = [3 6 -1;
    -6 -6 1;
    2 1 -1];

[ Q,R ] = Gram_Schmidt( A )