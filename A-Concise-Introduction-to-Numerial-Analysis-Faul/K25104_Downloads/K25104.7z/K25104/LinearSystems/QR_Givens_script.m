% Usage example for QR_Givens
% related to Exercise 2.8 

A = [3 6 -1;
    -6 -6 1;
    2 1 -1];

[ Q, R ] = QR_Givens( A )