% Usage example for QR_Householder_2
% related to Exercise 2.9 

A = [3 6 -1;
    -6 -6 1;
    2 1 -1];

[ Q, R ] = QR_Householder_2( A )