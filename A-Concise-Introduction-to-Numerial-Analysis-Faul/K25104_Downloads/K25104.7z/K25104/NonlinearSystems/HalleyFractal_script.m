% Usage example for HalleyFractal
% related to Exercise 4.2

p = [ 1 0 0 0 0 0 0 -1];
img = HalleyFractal(p)