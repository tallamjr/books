% Usage example for Bus_Dekker
% related to Exercise 4.3

p = [ 1 -1 -4 4];
a = -4;
b = 0;
tol = 0.01;
max = 100;
[ x,k ] = Bus_Dekker( p,a,b,tol,max )