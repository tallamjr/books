% Usage example for NewtonFractal
% related to Exercise 4.1

p = [ 1 0 0 0 0 0 0 -1];
img = NewtonFractal(p)