% Usage example for inv_FFT
% related to Exercise 8.7

x = [2 0 6 -2 6 0 6 2];
[ y ] = inv_FFT( x )