% Usage example for multistep_order
% related to Exercise 6.4

rho = [1/2; -3; 3/2; 1];
sigma = [0; 0; 3; 0];
[ p ] = multistep_order( rho,sigma )