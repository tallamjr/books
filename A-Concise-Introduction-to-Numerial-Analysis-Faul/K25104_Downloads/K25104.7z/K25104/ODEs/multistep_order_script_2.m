% Usage example for multistep_order
% related to Exercise 6.5

rho = [2; -3; 1];
sigma = [-5; -20; 13]/12;
[ p ] = multistep_order( rho,sigma )