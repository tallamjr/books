% Usage example for multistep_order
% related to Exercise 6.11

rho = [-2/11; 9/11; -18/11; 1];
sigma = [0; 0; 0; 6/11];
[ p ] = multistep_order( rho,sigma )